# 主机验证

在仓库根目录执行：

```powershell
cmd /c tests\run_checks.cmd
```

脚本使用 MSVC 或 PATH 中的 GCC，检查 SPWM、采样偏置、滑动 RMS、采样到 PI 的闭环连接、菜单及 OLED 状态文字，以及键盘扫描和去抖。脚本将包括断言中止在内的非零退出码视为失败。

当前路径为 ADC DMA → 上一周偏置扣除 → Rank1 电压 RMS → 1 ms 节拍 PI → INV_SetAmplitude → TIM1 PWM。默认闭环、50 Hz、目标 20 V RMS，Kp/Ki 初始为 0，须先设置至少一个非零增益才能启动闭环输出。初始幅值仍保留 90%，范围 1%～99%，未新增软启动。TIM1 的死区和 Break 设置沿用 CubeMX。

A 切换输出命令，C 停止，D 进入菜单且停止输出。2/8 上下选择，4/6 减加，C/D 返回。七项依次为 FREQ、AMP、LOOP、TARGET、FEEDBACK、KP、KI；闭环时 AMP 只读并标记 AUTO。TARGET 每步 1 V，KP 每步 0.01 %/V，KI 每步 0.1 %/(V*s)，FEEDBACK 的 4/6 分别选 V1/Rank1、V2/Rank2。目标和增益的 0～999 是显示/设置范围，不是硬件额定值。参数不写 Flash，重启恢复头文件默认值。

主界面第一行 OPEN 表示开环，CL:SET 表示目标或增益待设置，CL:WAIT 表示偏置/RMS 尚未有效，CL:READY 表示反馈已有效且输出命令关闭，CL:RUN 表示闭环调节已具备运行条件且输出命令开启；CMD 不代表实测硬件状态。第三行如 `V1:19.8/20V` 表示反馈电压 RMS/目标，未有效时显示 `--.-`。显示读取短临界区快照，OLED/SPI 绘制期间不会屏蔽采样。

`inverter_sampling.c` 使用 ADC1 Rank1/IN6/PC0、Rank2/IN7/PC1、Rank3/IN8/PC2，依次为电压1、电压2、电流。规则序列已同步为三个 Rank；六个半字的循环 DMA 缓冲区分为两帧，半满和全满回调各处理一帧。启动顺序为外设初始化、`INV_SamplingStart()` 校准并就绪 DMA、`INV_Init()` 启动 TIM1/TIM5。

`inverter_sampling.h` 中三组 K/B 是 `value = K * ADC原始计数 - B` 的线性拟合参数，保留当前文件给出的三组数值，实际精度需用参考仪表核对。`INV_SamplingGetData(&data)` 读取一致快照，包含原始值 `raw`、拟合值 `value`、上一周均值 `offset`、扣偏置值 `ac`、`offset_valid` 和已处理帧号 `sequence`。快照用于查看最新数据，不能通过低速主循环读取快照代替逐点处理来计算 RMS。

正弦表索引进入 0 时调用 `INV_SamplingNotifyCycle()`。DMA 入口仅在周期号改变时，以上一完整周期各路原始均值建立偏置；启动后的部分周期丢弃，再收满一周后才置 `offset_valid=1`。本周固定使用上一周偏置，公式为 `offset=K*mean(raw_previous_cycle)-B`，`ac=value-offset`，因此不会残留两次 B 的误差。周期按 DMA 回调观察到的边界划分，存在采样帧量级的边界量化/延迟；不假定每周固定点数。该方法会同时去掉信号本身的直流分量。

当前 SYSCLK/HCLK 为 HSI 16 MHz，APB1/APB2 均不分频，TIM1/TIM5 时钟均为 16 MHz。TIM1 中心对齐、PSC=0、ARR=800，载波仍为 10 kHz；三相初始 CCR 均为 400。RCR=0、TRGO=Update，上下溢出名义上产生 20 kHz ADC 触发；UDIS 临时屏蔽和软件 UG 会影响触发间隔。ADC 同步不分频，时钟为 16 MHz，每路采样 47.5 周期加 12.5 周期转换，三路扫描约 11.25 us。TIM5 默认 ARR=888，更新约 17.99775 kHz，对应基波约 49.99375 Hz；菜单更改频率时会重算 ARR。死区 DTG=5、CKD=DIV1，对应 312.5 ns；SPI2 保留 /32，SCK 为 500 kHz。HSE_VALUE=8 MHz 保留为外部晶振参数，当前未将其选作系统时钟。

实际处理耗时、采样间隔、丢样、HSI 时钟误差及标定精度需上板测量，不能将名义触发频率当作已验证采样率。RMS 窗口按名义 20 kHz/当前基波频率取整：50 Hz 时 400 点，30 Hz 时 667 点，100 Hz 时 200 点。它是近似整周窗口，仍须实测采样率。

`inverter_control_tools.c` 提供以下接口：

- `INV_ResetVoltageControl()`：清除滑动窗和积分状态；开始闭环或改变采样配置时调用，关闭输出也会自动调用。
- `INV_CalculateVoltageRms(voltage)`：每个等间隔新样本调用一次，输入为去偏置后的实际瞬时电压（V），按当前窗口计算 `sqrt(sum(v*v)/N)`，窗口未满返回 `-1.0f`。
- `INV_VoltagePI(target_rms, measured_rms, kp, ki, dt)`：误差为目标减实测；`kp` 单位 %/V，`ki` 单位 %/(V*s)，`dt` 是实际 PI 调用间隔（s）。积分从当前幅值起步，带饱和抗积分累积，输出四舍五入为整数百分比，再调用 `INV_SetAmplitude()`。未启用输出、RMS 或增益为负、dt 不大于 0 时不调节幅值。

RMS/PI 不检查 NaN、无穷大或计算溢出；调用方须保证输入及中间运算结果为有限数值。

DMA 路径统一使用 `INV_ProcessVoltageSample()`：每个有效样本更新 RMS 和显示值，满窗后以 HAL tick 的 1 ms 节拍调用 PI，积分 dt 按真实 tick 差值计算，不包含等待满窗的时间。旧的逐点 PI 包装入口已移除。菜单刷新和菜单等待都不驱动 PI。采样启动以及偏置从有效转为无效时复位反馈，等待期间不逐点重复复位；固定偏置的线性换算仅在周期边界执行。输出启停、频率/反馈/模式/目标/增益切换均复位 RMS/积分，窗口长度仅在调频时重算。

底层 RMS/PI 由 DMA 串行处理，不能额外重复喂同一个样本。开闭环、目标、反馈通道和 Kp/Ki 的四个设定函数为 `inverter_menu.c` 内部静态函数，与按键处理放在一起；仅在菜单已关闭输出时修改参数，再调用公开复位接口清除旧状态，设定函数自身不再重复编写 PRIMASK 操作。频率、幅值接口还供 PWM 初始化和 PI 使用，保留在控制模块。

公开复位接口自行保存中断状态；已经关中断的控制接口直接调用内部复位函数，每次操作只保存、恢复一次 PRIMASK。主机检查在原 PRIMASK=0/1 下验证八个入口的调用次数及恢复状态，并检查菜单读键前输出已经关闭、无效采样等待期间无重复复位。主循环的按键刷新和 200 ms 周期刷新共用一个出口，避免同一轮重复绘制。

主机检查验证了 DMA→去偏置→RMS→PI 的方向、预热等待、开环不调节、反馈切换、不同频率窗口、菜单只读幅值及 OLED 状态文字。一个虚拟负载模型验证调节到目标 20 V 附近；测试所用 Kp/Ki 仅服务于该模型，不是板上建议参数，也不证明实际功率级闭环稳定。

这些检查不能替代实际电气验证、驱动器极性检查或功率级测试。

On the STM32G474 board, connect rows R1–R4 to PE0–PE3 and columns C1–C4
to PE4–PE7. `Keyboard_Init()` overrides CubeMX's push-pull/no-pull defaults
with open-drain rows and pulled-up inputs; retain its call after GPIO init.
No EXTI or additional timer configuration is needed. SysTick must remain 1 ms.

当前库保留项目连接器方向，逻辑映射如下：

```text
D C B A
# 9 6 3
0 8 5 2
* 7 4 1
```

键盘只保留一个待处理事件，主循环长时间阻塞时后续按键可能丢失；C 键优先占用待处理事件，由主循环处理停机。
